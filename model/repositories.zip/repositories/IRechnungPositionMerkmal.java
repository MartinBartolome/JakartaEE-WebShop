package model.repositories;

import java.util.ArrayList;

public interface IRechnungPositionMerkmal {
    entities.IRechnungPositionMerkmal read(int identifier);
    ArrayList<IRechnungPositionMerkmal> readFuerRechnungPosition(int identifier);
    long write(entities.IRechnungPositionMerkmal rechnungPositionMerkmal);
}
