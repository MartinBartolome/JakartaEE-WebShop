package model.repositories;

public interface IArtikelMerkmalBeschreibung {
    entities.IArtikelMerkmalBeschreibung read(int identifier);
    entities.IArtikelMerkmalBeschreibung read(int artikelMerkmalIdentifier, int sprache);
}
