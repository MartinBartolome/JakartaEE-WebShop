package model.repositories;

import model.drivers.*;

import java.sql.SQLException;

public class Lagerbestand implements ILagerbestand {
    @Override
    public entities.ILagerbestand readFuerArtikel(int identifier) {
        entities.ILagerbestand bean = null;
        try {
            String query = "SELECT * FROM LAGERBESTAND WHERE ARTIKEL_IDENTIFIER=?";
            IParameter parameter = new ParameterTypeInt(0, identifier);
            IDriver driver = Factory.create();
            assert driver != null;
            IQueryResultsHandle handle = driver.runQuery(query, parameter);
            handle.getReader().next();
            bean = new entities.Lagerbestand();
            bean.setIdentifier(handle.getReader().getInt(0));
            bean.setArtikelIdentifier(handle.getReader().getInt(1));
            bean.setLagerIdentifier(handle.getReader().getInt(2));
            bean.setVerfuegbareEinheiten(handle.getReader().getFloat(3));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return bean;
    }

    @Override
    public entities.ILagerbestand read(int identifier) {
        entities.ILagerbestand bean = null;
        try {
            String query = "SELECT * FROM LAGERBESTAND WHERE IDENTIFIER=?";
            IParameter parameter = new ParameterTypeInt(0, identifier);
            IDriver driver = Factory.create();
            assert driver != null;
            IQueryResultsHandle handle = driver.runQuery(query, parameter);
            handle.getReader().next();
            bean = new entities.Lagerbestand();
            bean.setIdentifier(handle.getReader().getInt(0));
            bean.setArtikelIdentifier(handle.getReader().getInt(1));
            bean.setLagerIdentifier(handle.getReader().getInt(2));
            bean.setVerfuegbareEinheiten(handle.getReader().getFloat(3));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return bean;
    }
}
