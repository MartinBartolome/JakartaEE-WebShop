package model.repositories;

import model.drivers.*;

import java.sql.SQLException;

public class ArtikelBeschreibung implements IArtikelBeschreibung {
    @Override
    public entities.IArtikelBeschreibung read(int identifier) {
        entities.IArtikelBeschreibung bean = null;
        try {
            String query = "SELECT * FROM ARTIKELBESCHREIBUNG WHERE IDENTIFIER=?";
            IParameter parameter = new ParameterTypeInt(0, identifier);
            IDriver driver = Factory.create();
            assert driver != null;
            IQueryResultsHandle handle = driver.runQuery(query, parameter);
            handle.getReader().next();
            bean = new entities.ArtikelBeschreibung();
            bean.setIdentifier(handle.getReader().getInt(0));
            bean.setArtikelIdentifier(handle.getReader().getInt(1));
            bean.setSprache(handle.getReader().getInt(2));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return bean;
    }

    @Override
    public entities.IArtikelBeschreibung read(int artikelIdentifier, int sprache) {
        entities.IArtikelBeschreibung bean = null;
        try {
            String query = "SELECT * FROM ARTIKELBESCHREIBUNG WHERE ARTIKELIDENTIFIER=? AND SPRACHE=?";
            IParameter[] parameters = {
                new ParameterTypeInt(0, artikelIdentifier),
                new ParameterTypeInt(1, sprache),
            };
            IDriver driver = Factory.create();
            assert driver != null;
            IQueryResultsHandle handle = driver.runQuery(query, parameters);
            handle.getReader().next();
            bean = new entities.ArtikelBeschreibung();
            bean.setIdentifier(handle.getReader().getInt(0));
            bean.setArtikelIdentifier(handle.getReader().getInt(1));
            bean.setSprache(handle.getReader().getInt(2));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return bean;
    }
}
