package model.repositories;

import java.util.ArrayList;

public interface IRechnung {
    entities.IRechnung read(int identifier);
    ArrayList<entities.IRechnung> readFuerKunde(int identifier);
    long write(entities.IRechnung rechnung);
}
