package model.repositories;

public interface ILagerbestand {
    entities.ILagerbestand readFuerArtikel(int identifier);
    entities.ILagerbestand read(int identifier);
}
