package model.repositories;

public interface IBestellungPositionMerkmal {
    entities.IBestellungPositionMerkmal readFuerBestellungPosition(int identifier);
    entities.IBestellungPositionMerkmal read(int identifier);
}
