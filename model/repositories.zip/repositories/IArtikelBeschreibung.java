package model.repositories;

public interface IArtikelBeschreibung {
    entities.IArtikelBeschreibung read(int identifier);
    entities.IArtikelBeschreibung read(int artikelIdentifier, int sprache);
}
