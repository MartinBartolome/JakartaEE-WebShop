package model.repositories;

public interface IPreisProEinheit {
    entities.IPreisProEinheit readFuerArtikel(int identifier);
}
