package model.repositories;

import model.drivers.*;
import java.sql.SQLException;
import java.util.ArrayList;

public class ArtikelMerkmal implements IArtikelMerkmal{
    @Override
    public entities.IArtikelMerkmal read(int identifier) {
        entities.IArtikelMerkmal bean = null;
        try {
            String query = "SELECT * FROM ARTIKELMERKMAL WHERE IDENTIFIER=?";
            IParameter parameter = new ParameterTypeInt(0, identifier);
            IDriver driver = Factory.create();
            assert driver != null;
            IQueryResultsHandle handle = driver.runQuery(query, parameter);
            handle.getReader().next();
            bean = new entities.ArtikelMerkmal();
            bean.setIdentifier(handle.getReader().getInt(0));
            bean.setArtikelIdentifier(handle.getReader().getInt(1));
            bean.setSchluessel(handle.getReader().getString(2));
            bean.setWert(handle.getReader().getString(3));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return bean;
    }

    @Override
    public ArrayList<entities.IArtikelMerkmal> readFuerArtikel(int identifier) {
        ArrayList<entities.IArtikelMerkmal> beans = new ArrayList<>();
        try {
            String query = "SELECT * FROM ARTIKELMERKMAL WHERE ARTIKELIDENTIFIER=?";
            IParameter parameter = new ParameterTypeInt(0, identifier);
            IDriver driver = Factory.create();
            assert driver != null;
            IQueryResultsHandle handle = driver.runQuery(query, parameter);
            while (handle.getReader().next()) {
                entities.IArtikelMerkmal bean = new entities.ArtikelMerkmal();
                bean.setIdentifier(handle.getReader().getInt(0));
                bean.setArtikelIdentifier(handle.getReader().getInt(1));
                bean.setSchluessel(handle.getReader().getString(2));
                bean.setWert(handle.getReader().getString(3));
                beans.add(bean);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return beans;
    }
}
