package model.repositories;

public interface IZahlungsArt {
    entities.IZahlungsArt readFuerKunde(int identifier);
    void overwrite(entities.IZahlungsArt zahlungsArt);
}
