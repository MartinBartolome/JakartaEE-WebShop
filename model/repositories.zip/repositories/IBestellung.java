package model.repositories;
import java.util.ArrayList;

public interface IBestellung {
    ArrayList<entities.IBestellung> readFuerKunde(int identifier);
    entities.IBestellung read(int identifier);
    void overwrite(entities.IBestellung bestellung);
    long write(entities.IBestellung bestellung);
}
