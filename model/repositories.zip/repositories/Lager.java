package model.repositories;

import model.drivers.*;
import java.sql.SQLException;

public class Lager implements ILager {
    @Override
    public entities.ILager read(int identifier) {
        entities.ILager bean = null;
        try {
            String query = "SELECT * FROM LAGER WHERE IDENTIFIER=?";
            IParameter parameter = new ParameterTypeInt(0, identifier);
            IDriver driver = Factory.create();
            assert driver != null;
            IQueryResultsHandle handle = driver.runQuery(query, parameter);
            handle.getReader().next();
            bean = new entities.Lager();
            bean.setIdentifier(handle.getReader().getInt(0));
            bean.setBeschreibung(handle.getReader().getString(1));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return bean;
    }
}
