package model.repositories;

import java.util.ArrayList;

public interface IGruppeMerkmal {
    ArrayList<entities.IGruppeMerkmal> readFuerGruppe(int gruppeIdentifier);
    entities.IGruppeMerkmal read(int identifier);
}
