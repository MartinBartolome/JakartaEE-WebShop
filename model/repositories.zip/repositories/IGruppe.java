package model.repositories;

public interface IGruppe {
    entities.IGruppe read(int identifier);
}
