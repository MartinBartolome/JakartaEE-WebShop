package model.repositories;

import java.util.ArrayList;

public interface IBestellungPosition {
    ArrayList<entities.IBestellungPosition> readFuerBestellung(int identifier);
    void write(ArrayList<entities.IBestellungPosition> bestellungPositionen);
}
