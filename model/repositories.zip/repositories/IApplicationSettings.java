package model.repositories;

import jakarta.json.JsonException;

import java.io.IOException;

public interface IApplicationSettings {
    entities.IApplicationSettings read(String fileName) throws JsonException, IOException;
}
