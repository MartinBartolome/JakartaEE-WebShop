package model.repositories;

public interface IKunde {
    entities.IKunde read(int identifier);
    entities.IKunde read(String eMailAdresse);
    void overwrite(entities.IKunde kunde);
    long write(entities.IKunde kunde);
}
