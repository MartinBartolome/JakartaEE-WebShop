package model.repositories;

import java.util.ArrayList;

public interface IRechnungPosition {
    ArrayList<entities.IRechnungPosition> readFuerRechnung(int identifier);
    void write(ArrayList<entities.IRechnungPosition> rechnungPositionen);
}
