package model.repositories;

import java.util.ArrayList;

public interface IArtikelMerkmal {
    entities.IArtikelMerkmal read(int identifier);
    ArrayList<entities.IArtikelMerkmal> readFuerArtikel(int identifier);
}
