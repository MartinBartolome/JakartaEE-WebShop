package model.repositories;

public interface ILager {
    entities.ILager read(int identifier);
}
