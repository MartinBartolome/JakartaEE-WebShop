package model.repositories;

public interface IAdresse {
    entities.IAdresse read(int identifier);
    long write(entities.IAdresse adresse);
    void overwrite(entities.IAdresse adresse);
}
