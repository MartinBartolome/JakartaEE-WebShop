package model.repositories;

import model.drivers.*;

import java.sql.SQLException;
import java.util.ArrayList;

public class Artikel implements IArtikel {
    @Override
    public ArrayList<entities.IArtikel> readFuerArtikelArt(int identifier) {
        ArrayList<entities.IArtikel> beans = new ArrayList<>();
        try {
            String query = "SELECT * FROM ARTIKEL WHERE ARTIKELART=?";
            IParameter parameter = new ParameterTypeInt(0, identifier);
            IDriver driver = Factory.create();
            assert driver != null;
            IQueryResultsHandle handle = driver.runQuery(query, parameter);
            while (handle.getReader().next()) {
                entities.IArtikel bean = new entities.Artikel();
                bean.setIdentifier(handle.getReader().getInt(0));
                bean.setNummer(handle.getReader().getInt(1));
                bean.setArtikelArt(handle.getReader().getInt(2));
                bean.setEinheit(handle.getReader().getInt(3));
                bean.setZustand(handle.getReader().getInt(4));
                beans.add(bean);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return beans;
    }

    @Override
    public entities.IArtikel read(int identifier) {
        entities.Artikel bean = null;
        try {
            String query = "SELECT * FROM ARTIKEL WHERE IDENTIFIER=?";
            IParameter parameter = new ParameterTypeInt(0, identifier);
            IDriver driver = Factory.create();
            assert driver != null;
            IQueryResultsHandle handle = driver.runQuery(query, parameter);
            handle.getReader().next();
            bean = new entities.Artikel();
            bean.setIdentifier(handle.getReader().getInt(0));
            bean.setNummer(handle.getReader().getInt(1));
            bean.setArtikelArt(handle.getReader().getInt(2));
            bean.setEinheit(handle.getReader().getInt(3));
            bean.setZustand(handle.getReader().getInt(4));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return bean;
    }
}
