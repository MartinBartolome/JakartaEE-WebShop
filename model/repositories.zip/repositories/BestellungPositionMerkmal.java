package model.repositories;

public class BestellungPositionMerkmal implements IBestellungPositionMerkmal {
    @Override
    public entities.IBestellungPositionMerkmal readFuerBestellungPosition(int identifier) {
        return null;
    }

    @Override
    public entities.IBestellungPositionMerkmal read(int identifier) {
        return null;
    }
}
