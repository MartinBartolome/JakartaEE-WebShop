package model.repositories;
import java.util.ArrayList;

public interface IArtikel {
    ArrayList<entities.IArtikel> readFuerArtikelArt(int identifier);
    entities.IArtikel read(int identifier);
}
