package model.repositories;

import java.util.ArrayList;

public interface IGruppeMerkmalBeschreibung {
    entities.IGruppeMerkmalBeschreibung read(int identifier);
    ArrayList<entities.IGruppeMerkmalBeschreibung> read(int gruppeMerkmalIdentifier, int sprache);
}
